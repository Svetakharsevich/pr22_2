package com.example.pr

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.TextView
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class Music : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)
        /*
        val apiKey = "gUAzbNgxFinJozpuGfgQErWIVKvvAdYyLunamCHq"
        val apiSecret = "Ваш секретный ключ"
        val artistName = "Nirvana" // Имя исполнителя, о котором вы хотите получить информацию

        val discogsApiUrl = "https://api.discogs.com/database/search?q=$artistName&type=artist"

        // Выполняем запрос в фоновом потоке
        AsyncTask.execute {
            val client = OkHttpClient()

            val request = Request.Builder()
                .url(discogsApiUrl)
                .header("Authorization", "Discogs key=$apiKey")
                .build()

            try {
                val response: Response = client.newCall(request).execute()
                Log.d("MyLog", "Volley: $response")
                val responseBody = response.body?.string()

                if (response.isSuccessful) {
                    // Обработка успешного ответа
                    runOnUiThread {
                        // Выводите информацию или обрабатывайте ее здесь
                    }
                } else {
                    Log.d("MyLog", "Volley:")
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }*/
    }
    private fun getResualt()
    {
        val textInfoSet : TextView= findViewById(R.id.textView)

//meta status

        val artistName = textInfoSet.text.toString() // Имя исполнителя, о котором вы хотите получить информацию
       val url= "https://api.discogs.com/artists/1?callback=Nirvana"

        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(
            com.android.volley.Request.Method.GET, url,
            { response ->
                val txt =JSONObject(response)
                val height=txt.getJSONObject("meta")
                textInfoSet.text = height.toString()
                Log.d("MyLog", "Volley: $response")
            },
            { error ->
                Log.d("MyLog", "Volley error: ${error.message}")
            })

        queue.add(stringRequest)

    }

    fun getResualtBut(view: View) {
        getResualt()
    }

}